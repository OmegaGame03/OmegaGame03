from django.contrib import admin

from django.contrib import admin
from .models import Transport, Hotel, Booking

admin.site.register(Transport)
admin.site.register(Hotel)
admin.site.register(Booking)
