from django.db import models
from django.contrib.auth.models import User

# Modello per i Trasporti
class Transport(models.Model):
    name = models.CharField(max_length=100)  # Nome del mezzo (es. Treno, Aereo)
    origin = models.CharField(max_length=100)  # Città di partenza
    destination = models.CharField(max_length=100)  # Città di destinazione
    duration = models.DurationField()  # Durata del viaggio
    cost = models.DecimalField(max_digits=10, decimal_places=2)  # Costo del viaggio

    def __str__(self):
        return f"{self.name}: {self.origin} to {self.destination}"


# Modello per gli Hotel
class Hotel(models.Model):
    name = models.CharField(max_length=100)  # Nome dell'hotel
    address = models.TextField()  # Indirizzo
    city = models.CharField(max_length=100)  # Città
    price_range = models.CharField(max_length=50)  # Fascia di prezzo (es. €€, €€€)
    rating = models.FloatField()  # Valutazione (es. 4.5)

    def __str__(self):
        return self.name
    
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    saved_transports = models.ManyToManyField(Transport, blank=True)
    saved_hotels = models.ManyToManyField(Hotel, blank=True)

    def __str__(self):
        return self.user.username
    
class Booking(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    transport = models.ForeignKey(Transport, on_delete=models.SET_NULL, null=True, blank=True)
    hotel = models.ForeignKey(Hotel, on_delete=models.SET_NULL, null=True, blank=True)
    start_date = models.DateField()
    end_date = models.DateField()
    booking_date = models.DateField(null=True, blank=True)

    def __str__(self):
        if self.transport:
            return f"Booking for {self.transport.name}"
        elif self.hotel:
            return f"Booking for {self.hotel.name}"
        return "Booking"

