from django.urls import path
from . import views

urlpatterns = [
    path('search-transport/', views.search_transport, name='search_transport'),
    path('search-hotels/', views.search_hotels, name='search_hotels'),
    path('save-transport/<int:transport_id>/', views.save_transport, name='save_transport'),
    path('save-hotel/<int:hotel_id>/', views.save_hotel, name='save_hotel'),
    path('add-transport/', views.add_transport, name='add_transport'),
    path('add-hotel/', views.add_hotel, name='add_hotel'),
    path('add-booking/', views.add_booking, name='add_booking'),
    path('my-bookings/', views.my_bookings, name='profile'),
    path('register/', views.register, name='register'),
    path('add-booking-page/', views.add_booking_page, name='add_booking_page'),
    path('delete-booking/<int:booking_id>/', views.delete_booking, name='delete_booking'),
    path('edit-booking/<int:booking_id>/', views.edit_booking, name='edit_booking'),
]