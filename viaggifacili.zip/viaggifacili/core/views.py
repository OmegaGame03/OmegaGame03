from django.shortcuts import render, redirect
from django.http import JsonResponse
from .models import Transport, Hotel, Profile, Booking
from .forms import TransportForm, HotelForm, BookingForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.shortcuts import get_object_or_404


from django.shortcuts import render
from .models import Transport, Hotel

def home(request):
    if request.user.is_authenticated:
        query = request.GET.get('query', '')
        search_type = request.GET.get('type', '')
        results = []

        if query:
            if search_type == 'transport':
                results = Transport.objects.filter(destination__icontains=query)
            elif search_type == 'hotel':
                #o city o address deve essere uguale a query
                results = Hotel.objects.filter(city__icontains=query)
                results |= Hotel.objects.filter(address__icontains=query)
                
        
        return render(request, 'core/home_authenticated.html', {
            'query': query,
            'results': results,
            'search_type': search_type,
        })
    else:
        return render(request, 'core/home_guest.html')


def search_page(request):
    return render(request, 'search.html')


def search_transport(request):
    destination = request.GET.get('destination')
    transport_type = request.GET.get('type')
    queryset = Transport.objects.all()

    if destination:
        queryset = queryset.filter(destination__icontains=destination)
    if transport_type:
        queryset = queryset.filter(name__icontains=transport_type)

    if 'api' in request.GET:
        data = list(queryset.values())
        return JsonResponse(data, safe=False)
    
    return render(request, 'results.html', {'results': queryset})


def search_hotels(request):
    city = request.GET.get('city')
    queryset = Hotel.objects.all()

    if city:
        queryset = queryset.filter(city__icontains=city)

    if 'api' in request.GET:
        data = list(queryset.values())
        return JsonResponse(data, safe=False)
    
    return render(request, 'results.html', {'results': queryset})


@login_required
def save_transport(request, transport_id):
    transport = Transport.objects.get(id=transport_id)
    profile = Profile.objects.get(user=request.user)
    profile.saved_transports.add(transport)
    return redirect('saved_items')


@login_required
def save_hotel(request, hotel_id):
    hotel = Hotel.objects.get(id=hotel_id)
    profile = Profile.objects.get(user=request.user)
    profile.saved_hotels.add(hotel)
    return redirect('saved_items')


@login_required
def saved_items(request):
    profile = Profile.objects.get(user=request.user)
    transports = profile.saved_transports.all()
    hotels = profile.saved_hotels.all()
    return render(request, 'core/saved_items.html', {'transports': transports, 'hotels': hotels})

@login_required
def add_transport(request):
    if request.method == 'POST':
        form = TransportForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = TransportForm()
    return render(request, 'core/add_transport.html', {'form': form})

@login_required
def add_hotel(request):
    if request.method == 'POST':
        form = HotelForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = HotelForm()
    return render(request, 'core/add_hotel.html', {'form': form})

from django.http import JsonResponse
from datetime import date

def add_booking(request):
    if request.method == "POST":
        item_type = request.POST.get('type')
        item_id = request.POST.get('id')
        start_date = request.POST.get('start_date')
        end_date = request.POST.get('end_date')

        if not (item_type and item_id and start_date and end_date):
            return render(request, 'core/add_booking_page.html', {
                'error': 'Tutti i campi sono obbligatori'
            })

        try:
            if item_type == "transport":
                transport = get_object_or_404(Transport, id=item_id)
                Booking.objects.create(
                    user=request.user,
                    transport=transport,
                    start_date=start_date,
                    end_date=end_date,
                    booking_date=date.today(),
                )
            elif item_type == "hotel":
                hotel = get_object_or_404(Hotel, id=item_id)
                Booking.objects.create(
                    user=request.user,
                    hotel=hotel,
                    start_date=start_date,
                    end_date=end_date,
                    booking_date=date.today(),
                )
            else:
                return render(request, 'core/add_booking_page.html', {
                    'error': 'Tipo non valido'
                })

            return render(request, 'core/success.html')
        except Exception as e:
            return render(request, 'core/add_booking_page.html', {
                'error': str(e)
            })
    else:
        return redirect('home')

@login_required
def my_bookings(request):
    bookings = Booking.objects.filter(user=request.user)
    return render(request, 'core/my_bookings.html', {'bookings': bookings})


def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f"Account creato con successo per {username}!")
            return redirect('login')
    else:
        form = UserCreationForm()
    return render(request, 'core/register.html', {'form': form})

def add_booking_page(request):
    item_type = request.GET.get('type')
    item_id = request.GET.get('id')

    if not item_type or not item_id:
        return render(request, 'core/add_booking_page.html', {'error': 'Dati mancanti'})

    item = None
    if item_type == 'transport':
        item = get_object_or_404(Transport, id=item_id)
    elif item_type == 'hotel':
        item = get_object_or_404(Hotel, id=item_id)
    else:
        return render(request, 'core/add_booking_page.html', {'error': 'Tipo non valido'})

    return render(request, 'core/add_booking_page.html', {
        'item_type': item_type,
        'item': item,
    })
    
@login_required
def delete_booking(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id, user=request.user)
    booking.delete()
    return redirect('profile')

def edit_booking(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id, user=request.user)

    if request.method == "POST":
        booking.start_date = request.POST.get('start_date')
        booking.end_date = request.POST.get('end_date')
        booking.save()
        return redirect('profile')

    return render(request, 'core/edit_booking.html', {'booking': booking})
