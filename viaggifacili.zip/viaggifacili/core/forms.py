from django import forms
from .models import Transport, Hotel, Booking

# Form per aggiungere trasporti
class TransportForm(forms.ModelForm):
    class Meta:
        model = Transport
        fields = ['name', 'origin', 'destination', 'duration', 'cost']
        widgets = {
            'duration': forms.TextInput(attrs={'placeholder': 'Formato: HH:MM:SS'}),
        }

# Form per aggiungere hotel
class HotelForm(forms.ModelForm):
    class Meta:
        model = Hotel
        fields = ['name', 'address', 'city', 'price_range', 'rating']

class BookingForm(forms.ModelForm):
    class Meta:
        model = Booking
        fields = ['transport', 'hotel', 'start_date', 'end_date']
        widgets = {
            'start_date': forms.DateInput(attrs={'type': 'date'}),
            'end_date': forms.DateInput(attrs={'type': 'date'}),
        }
